<?php

namespace App\Http\Controllers;

use App\Order\OrderRepository;
use App\Order\OrderService;
use App\RajaOngkir\RajaOngkirService;
use App\User\PhoneNumberService;
use App\User\UserRepository;
use App\UserOrder\UserOrderRepository;
use Illuminate\Http\Request;

class ApiController extends Controller{
    protected $order_service, $phone_validate, $user, $user_order;
    public function __construct(OrderService $orderService, PhoneNumberService $phoneValidate, UserRepository $user) {
        $this->order_service    = $orderService;
        $this->phone_validate   = $phoneValidate;
        $this->user             = $user;
        $this->user_order       = new UserOrderRepository();
    }

    public function createOrder(Request $request){
        // ala-ala proses
        //sleep(1);
        $data   = json_decode(json_encode($request->all()));

        $order  = $this->order_service->makeOrder($data);
        $orderId  = $order->id;


        //$result   = $this->order_service->find($orderId);
        return response()->json([
            'status'    => (bool)$order,
            'data'      => $order
        ]);
    }

    public function orderList(Request $request){
        $rememberToken  = $request->get('remember_token');
        $result         = $this->order_service->getListByToken($rememberToken);

        return response()->json([
            'status'    => (bool)$result,
            'data'      => $result
        ]);
    }

    public function orderDetail($orderId = null, Request $request){
        $rememberToken  = $request->get('remember_token');
        $result         = $this->order_service->findDetail($rememberToken, $orderId);
        $packages       = $this->order_service->_allPackage();
        if(!empty($packages[($result->package_id - 1)]) AND $result){
            $package    = $packages[($result->package_id - 1)];
        }else{
            $package    = $this->order_service->getOldPackage($result->package);
        }
        $price      = $this->order_service->_calculateGrandTotal($result, $package);
        $prices     = $this->order_service->generateOrderDetail($result, $package);

        return response()->json([
            'status'    => (bool)$result,
            'data'      => $result,
            'package'   => $package,
            'price'     => $price,
            'prices'    => $prices
        ]);
    }

    public function validatePhone(Request $request){
        $phone      = $request->get('phone');
        $full_name  = $request->get('full_name');
        $deviceHW  = $request->get('device_hardware');
        $deviceId  = $request->get('device_id');
        $rememberToken  = $request->get('remember_token');
        $result         = $this->phone_validate->standardPhone($phone);
        $status          = true;
        $resultMsg      = '';
        if(!$result){
            $status     = false;
            $resultMsg  = 'No hp tidak valid';
        }
        if(date("Y-m-d H:i:s") > "2018-11-29 00:00:00"){
            $resultMsg  = "LaundryTaxi sementara tutup beroperasi hingga waktu yang akan diumumkan selanjutnya, Terimakasih telah mempercayakan jasa Laundry Service Anda kepada kami selama ini. Cinta tidak akan pernah diketahui dalamnya sampai merasakan detik-detik perpisahan. - Aris Susanti (Founder LaundryTaxi)";
            $status     = false;
        }

        $needActivation = $this->order_service->needForValidateUserPhone($full_name, $result, $rememberToken, $deviceHW, $deviceId, $status);

        if($status == true && $needActivation){
            $needActivation = true;
        }


        return response()->json([
            'status'    => (bool)$status,
            'data'      => $result,
            'activation' => $needActivation,
            'message'   => $resultMsg
        ]);
    }

    public function resendActivationCode(Request $request){
        $phone      = $request->get('phone');
        $result     = $this->phone_validate->standardPhone($phone);
        $needActivation = $this->order_service->resendActivationCode($phone);

        return response()->json([
            'status'    => (bool)$result,
            'data'      => $result,
            'activation' => $needActivation
        ]);
    }

    public function submitValidationCode(Request $request){
        $phone      = $request->get('phone');
        $code       = $request->get('activate_code');
        $result     = $this->order_service->submitValidationCode($phone,$code);

        return response()->json([
            'status'    => (bool)$result['status'],
            'data'      => $result['message'],
            'remember_token'    => ($result['status']) ? $result['user']->remember_token : ''
        ]);
    }

    public function getPackages(Request $request){
        $token      = $request->get('remember_token');
        $packages   = $this->order_service->getPackages($token);

        return response()->json([
            'status'    => true,
            'data'      => $packages
        ]);
    }

    public function findValidatePackage(Request $request){
        $packageId      = $request->get('package');
        $rememberToken  = $request->get('remember_token');
        $result         = $this->order_service->findAndValidatePackage($rememberToken, $packageId);

        return response()->json([
            'status'    => $result['status'],
            'data'      => $result['message']
        ]);
    }

    public function rejectOrder(Request $request){
        $pass       = $request->get('password');
        $orderId    = $request->get('order_id');
        $order      = null;
        if($pass == 22){
            $order  = $this->order_service->rejectOrder($orderId);
        }

        return response()->json([
            'status'    => $order
        ]);
    }

    public function courierPickedUp(Request $request){
        $pass       = $request->get('password');
        $orderId    = $request->get('order_id');
        $weight     = $request->get('weight');
        //$count      = $request->get('count');
        $order      = null;
        if($pass == 22 && $weight){
            $order  = $this->order_service->pickupSuccess($orderId, $weight);
        }

        return response()->json([
            'status'    => $order
        ]);
    }

    public function checkForUpdate(Request $request){
        $version    = $request->get('version');
        $status     = false;
        if($version != '0.0.7'){
            $status     = true;
        }

        return response()->json([
            'status'    => $status,
            'data'      => ''
        ]);
    }

    public function findUser(Request $request){
        $q      = $request->get('q');
        $users  = $this->user->getUserAjax($q);

        return response()->json($users);
    }

    public function getLastOrder(Request $request){
        $userId = $request->get('user_id');
        $order  = $this->order_service->findLastOrderByUserId($userId);

        return response()->json($order);
    }

    public function getProvinces(Request $request){
        $isJson     = $request->get('is_json');
        $provinceId = $request->get('province_id');
        $orderId    = $request->get('order_id');
        $order      = $this->user_order->findOrderById($orderId);
        if($order){
            $provinceId = $order->customer_province;
        }

        $rajaOngkir = new RajaOngkirService();
        $provinces  = $rajaOngkir->getProvinces();

        if($isJson){
            return response()->json($provinces);
        }

        return view('api.provinces', compact('provinces','provinceId'));
    }

    public function getCities(Request $request){
        $isJson     = $request->get('is_json');
        $provinceId = $request->get('province_id');
        $cityId     = $request->get('city_id');
        $orderId    = $request->get('order_id');
        $order      = $this->user_order->findOrderById($orderId);
        if($order){
            $cityId     = $order->customer_city;
            $provinceId = $order->customer_province;
        }

        $rajaOngkir = new RajaOngkirService();
        $cities     = $rajaOngkir->getCities($provinceId);

        if($isJson){
            return response()->json($cities);
        }

        return view('api.cities', compact('cities','provinceId','cityId'));
    }

    public function getDistricts(Request $request){
        $isJson     = $request->get('is_json');
        $cityId     = $request->get('city_id');
        $districtId = $request->get('district_id');
        $orderId    = $request->get('order_id');
        $order      = $this->user_order->findOrderById($orderId);
        if($order){
            $cityId     = $order->customer_city;
            $districtId = $order->customer_district;
        }

        $rajaOngkir = new RajaOngkirService();
        $districts  = $rajaOngkir->getDistricts($cityId);

        if($isJson){
            return response()->json($districts);
        }

        return view('api.districts', compact('districts','districtId','cityId'));
    }

    public function getShipments(Request $request){
        $isJson     = $request->get('is_json');
        $districtId = $request->get('district_id');
        $shipmentCode   = $request->get('shipment_code');

        $orderId    = $request->get('order_id');
        $order      = $this->user_order->findOrderById($orderId);
        if($order){
            $shipmentCode   = $order->delivery_service;
            $districtId     = $order->customer_district;
        }

        $rajaOngkir = new RajaOngkirService();
        $shipments  = $rajaOngkir->getShipments($districtId);

        if($isJson){
            return response()->json($shipments);
        }

        return view('api.costs', compact('shipments','districtId','shipmentCode'));
    }

    public function getShipmentService(Request $request){
        $isJson     = $request->get('is_json');
        $districtId = $request->get('district_id');
        $serviceCode        = $request->get('delivery_service_code');
        $servicePackage     = $request->get('delivery_service_package');

        $orderId    = $request->get('order_id');
        $order      = $this->user_order->findOrderById($orderId);
        if($order){
            $serviceCode    = $order->delivery_service;
            $servicePackage = $order->delivery_package;
            $districtId     = $order->customer_district;
        }

        $rajaOngkir = new RajaOngkirService();
        $shipments  = $rajaOngkir->getShipments($districtId);

        if($isJson){
            return response()->json($shipments);
        }

        return view('api.service', compact('shipments','districtId','servicePackage','serviceCode'));
    }
}
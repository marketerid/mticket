<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Events\EventsRepository;
use App\Veritrans\Midtrans;

class IndexController extends Controller
{
    protected $event;
    public function __construct(EventsRepository $event)
    {
        $this->event = $event;
        Midtrans::$serverKey = env('MIDTRANS_SERVER_KEY');
        Midtrans::$isProduction = false;
    }

    public function index(Request $request)
    {
        $event = $this->event->getEvent();
        if ($request->ajax()) {
            return view('frontend.load', compact('event'));
        }
        return view('frontend.index', compact('event'));
    }

    public function event($type = null)
    {
        $event = $this->event->findType($type);
        $type = ucfirst($type);
        if (!$event->count()) {
            return 'no view';
        }
        return view('frontend.list', compact('type', 'event'));
    }

    public function viewEvent($type = null, $slug = null)
    {
        $event = $this->event->findSlugByEvent($slug);
        // dd($event);
        if (!$event) {
            return 'no event';
        } elseif ($event->type !== $type) {
            return 'no view';
        }
        return view('frontend.event', compact('event'));
    }

    public function registration(Request $request)
    {
        $inputs = $request->all();
        $register = $this->event->registration($inputs);
        if (!$register) {
            alertNotify(false, "Create Failed", $request);
            return redirect()->back();
        }
        return redirect(url('payment' . '?inv=' . $register->invoice));
    }

    public function payment(Request $request)
    {
        $inv = $request->get('inv');
        $payment = $this->event->findInvoice($inv);
        // return response()->json($payment->event[0]->city);
        // exit();
        if (!$payment) {
            return 'no inv';
        }
        return view('frontend.payment', compact('payment'));
    }

    public function token(Request $request)
    {
        $payment = $this->event->findInvoice($request->get('inv'));
        error_log('masuk ke snap token dri ajax');
        $midtrans = new Midtrans;
        $transaction_details = array(
            'order_id'      => $payment->invoice,
            'gross_amount'  => $payment->total
        );
        // Populate items
        $items = [
            array(
                'id'        => $payment->id,
                'price'     => $payment->total,
                'quantity'  => 1,
                'name'      => $payment->name
            )
        ];
        // Populate customer's billing address
        $billing_address = array(
            'first_name'    => $payment->name,
            'phone'         => $payment->phone,
            'country_code'  => 'IDN'
        );
        // Populate customer's shipping address
        $shipping_address = array(
            'first_name'    => $payment->name,
            'phone'         => $payment->phone,
            'country_code'  => 'IDN'
        );
        // Populate customer's Info
        $customer_details = array(
            'first_name'      => $payment->name,
            'email'           => $payment->email,
            'phone'           => $payment->phone,
            'billing_address' => $billing_address,
            'shipping_address' => $shipping_address
        );
        // Data yang akan dikirim untuk request redirect_url.
        $credit_card['secure'] = true;
        //ser save_card true to enable oneclick or 2click
        //$credit_card['save_card'] = true;
        $time = time();
        $custom_expiry = array(
            'start_time' => date("Y-m-d H:i:s O", $time),
            'unit'       => 'hour',
            'duration'   => 2
        );

        $transaction_data = array(
            'transaction_details' => $transaction_details,
            'item_details'       => $items,
            'customer_details'   => $customer_details,
            'credit_card'        => $credit_card,
            'expiry'             => $custom_expiry
        );

        try {
            $snap_token = $midtrans->getSnapToken($transaction_data);
            //return redirect($vtweb_url);
            echo $snap_token;
        } catch (Exception $e) {
            return $e->getMessage;
        }
    }
    public function finish(Request $request)
    {
        $result = $request->input('result_data');
        $result = json_decode($result);
        return redirect(url('payment?inv='.$result->order_id));
    }
    public function notification()
    {
        $midtrans = new Midtrans;
        $json_result = file_get_contents('php://input');
        $result = json_decode($json_result);
        if ($result) {
            $notif = $midtrans->status($result->order_id);
        }
        error_log(print_r($result, TRUE));
        
        $transaction = $notif->transaction_status;
        $type = $notif->payment_type;
        $order_id = $notif->order_id;
        $fraud = $notif->fraud_status;
        $donation = Donation::findOrFail($orderId);

        if ($transaction == 'capture') {
          // For credit card transaction, we need to check whether transaction is challenge by FDS or not
          if ($type == 'credit_card'){
            if($fraud == 'challenge'){
              // TODO set payment status in merchant's database to 'Challenge by FDS'
              // TODO merchant should decide whether this transaction is authorized or not in MAP
              $donation->setPending();
              }
              else {
              // TODO set payment status in merchant's database to 'Success'
              $donation->setSuccess();
              }
            }
          } else if ($transaction == 'settlement'){
          // TODO set payment status in merchant's database to 'Settlement'
          $donation->setSuccess();
          } else if($transaction == 'pending'){
          // TODO set payment status in merchant's database to 'Pending'
          $donation->setPending();
          } else if ($transaction == 'deny') {
          // TODO set payment status in merchant's database to 'Denied'
          $donation->setFailed();
        }
    }
}

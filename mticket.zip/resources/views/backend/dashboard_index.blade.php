@extends('backend')
@section('main')
<div class="page-content container-fluid">

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-bordered">
                <div class="panel-body">
					dashboard
				</div>
			</div>
		</div>
	</div>
</div>
@stop
